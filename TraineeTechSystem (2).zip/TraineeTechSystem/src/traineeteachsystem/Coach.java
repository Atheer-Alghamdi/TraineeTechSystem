
package traineeteachsystem;




import java.util.ArrayList;


 public class Coach implements Subject,User{
    private String name;
    private String ID;
    private String email;
    private ArrayList<Course> courses;
    private ArrayList<Observer> observers;

    public Coach() {
        courses = new ArrayList<>();
        observers = new ArrayList<>();
    }

   public Coach(String coachId) {
        this.courses = new ArrayList<>();
        this.ID = coachId;
    }

    public void registerObserver(Observer o) {
        observers.add(o);
    }

    public void removeObserver(Observer o) {
        observers.remove(o);
    }

    public void notifyObservers(String message) {
        for (Observer observer : observers) {
            observer.update(message);
        }
    }

    public void register(String name, String ID, String email) {
        this.name = name;
        this.ID = ID;
        this.email = email;
        System.out.println("Coach registered successfully");
    }

    public void addCourse(String courseName, String courseId, double price) {
        Course newCourse = new Course(courseName, courseId, price);
        courses.add(newCourse);
        System.out.println("Course added successfully!");
        notifyObservers(" New course added: " + newCourse.getName());
    }

    public ArrayList<Course> getCourses() {
        return courses;
    }
    
    public void viewTraineeProfiles(ArrayList<Trainee> trainees,String requestingCoachId) {
     
         if (requestingCoachId.equals(ID)) {
            for (Trainee trainee : trainees) {
                System.out.println("Trainee Profile:");
               System.out.println("Name: " + trainee.getName());
                System.out.println("ID: " + trainee.getID());
                System.out.println("Phone: " + trainee.getPhone());
                System.out.println("Email: " + trainee.getEmail());
                System.out.println("Sex: " + trainee.getSex());
                System.out.println("Weight: " + trainee.getWeight());
                System.out.println("Height: " + trainee.getHeight());
                System.out.println("Goal: " + trainee.getGoal());
            }
        } else {
            System.out.println("You are not authorized to view this trainee's profile.");
        }
        }

   
    }

    

