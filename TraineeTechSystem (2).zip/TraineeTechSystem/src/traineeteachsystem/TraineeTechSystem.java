
package traineeteachsystem;


//public class TraineeTechSystem {
    
   
   // public static void main(String[] args) {
      // TrainingManagementFacade facade = new TrainingManagementFacade();
      //  facade.start();
   // }

//} 
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class TraineeTechSystem  {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new TraineeTechSystemGUI().setVisible(true);
            }
        });
    }

    
     
}
