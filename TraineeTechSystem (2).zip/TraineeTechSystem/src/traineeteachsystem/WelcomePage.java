/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package traineeteachsystem;

/**
 *
 * @author uthir
 */
class WelcomePage {
    private WelcomeStrategy welcomeStrategy;
    

    public void setWelcomeStrategy(WelcomeStrategy welcomeStrategy) {
        this.welcomeStrategy = welcomeStrategy;
    }

    public void displayWelcome() {
        if (welcomeStrategy != null) {
            welcomeStrategy.displayWelcome();
        } else {
            System.out.println("Default welcome. Choose a strategy.");
        }
    }
}
