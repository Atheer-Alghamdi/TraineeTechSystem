/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package traineeteachsystem;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 *
 * @author Shahad
 */
public class TraineeTechSystemGUI extends JFrame{
 TrainingManagementFacade faced= new TrainingManagementFacade();
    private JPanel currentPanel;
    private ArrayList<Course> courses;

    public TraineeTechSystemGUI() {
        setTitle("Trainee Tech System");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center the frame

        courses = new ArrayList<>();

        displayMainMenu();
    }

    private void displayMainMenu() {
        currentPanel = new JPanel(new BorderLayout());

        JLabel titleLabel = new JLabel("Welcome to the Training Management System!");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        currentPanel.add(titleLabel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel(new GridLayout(3, 1, 0, 10));

        JButton coachBtn = new JButton("Register as Coach");
        coachBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayCoachRegistration();
                
            }
        });
        buttonPanel.add(coachBtn);

        JButton traineeBtn = new JButton("Register as Trainee");
        traineeBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayTraineeRegistration();
                
            }
        });
        buttonPanel.add(traineeBtn);

        JButton exitBtn = new JButton("Exit");
        exitBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        buttonPanel.add(exitBtn);

        currentPanel.add(buttonPanel, BorderLayout.CENTER);

        setContentPane(currentPanel);
        revalidate();
        repaint();
    }

    private void displayCoachRegistration() {
        currentPanel.removeAll();

        JLabel titleLabel = new JLabel("Coach Registration");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        currentPanel.add(titleLabel, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridLayout(4, 2, 10, 10));

        JTextField nameField = new JTextField();
        JTextField idField = new JTextField();
        JTextField emailField = new JTextField();

        formPanel.add(new JLabel("Name:"));
        formPanel.add(nameField);
        formPanel.add(new JLabel("ID:"));
        formPanel.add(idField);
        formPanel.add(new JLabel("Email:"));
        formPanel.add(emailField);
        formPanel.add(new JLabel(""));
        JButton registerBtn = new JButton("Register");
        registerBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText().trim();
                String id = idField.getText().trim();
                String email = emailField.getText().trim();
                 
                if (name.isEmpty() || id.isEmpty() || email.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    // Create a new Coach instance
                    //Coach coach = new Coach(id); //  'id' is the coach's ID
                  
                    // Register the coach
                     faced.registerCoach();
                    //coach.register(name, id, email);
                    JOptionPane.showMessageDialog(null, "Coach registered successfully!");
                    // Clear fields after registration
                    nameField.setText("");
                    idField.setText("");
                    emailField.setText("");
                    
                    displayCoachMenu();
                }
            }
        });
        formPanel.add(registerBtn);

        currentPanel.add(formPanel, BorderLayout.CENTER);

        JButton backBtn = new JButton("Back");
        backBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayMainMenu();
            }
        });
        currentPanel.add(backBtn, BorderLayout.SOUTH);

        revalidate();
        repaint();
       
    }
    private void displayCoachMenu() {
        
        
    // Create a new JFrame for the coach menu
    //JFrame coachMenuFrame = new JFrame("Coach Menu");

    // Create buttons for coach menu options
    currentPanel = new JPanel(new BorderLayout());

        JLabel titleLabel = new JLabel("Coach mune ");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        currentPanel.add(titleLabel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel(new GridLayout(3, 1, 0, 10));
    JButton manageCoursesButton = new JButton("Add Courses");
    manageCoursesButton.addActionListener(e -> {
        // Call method to display course management GUI
        displayAddCourse();
    });
 buttonPanel.add(manageCoursesButton );
    JButton viewTraineeProfilesButton = new JButton("View Trainee Profiles");
    viewTraineeProfilesButton.addActionListener(e -> {
        // Call method to display trainee profiles GUI
        displayTraineeProfiles();
    });
    buttonPanel.add(viewTraineeProfilesButton);

        JButton exitBtn = new JButton("beak");
        exitBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               displayMainMenu();
            }
        });
        buttonPanel.add(exitBtn);

        currentPanel.add(buttonPanel, BorderLayout.CENTER);

        setContentPane(currentPanel);
        revalidate();
        repaint();

}

private void displayAddCourse() {
     currentPanel.removeAll();
        JLabel titleLabel = new JLabel("Coach Add course");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        currentPanel.add(titleLabel, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridLayout(4, 2, 10, 10));

        JTextField nameField = new JTextField();
        JTextField idField = new JTextField();
        JTextField priseField = new JTextField();

        formPanel.add(new JLabel("Name:"));
        formPanel.add(nameField);
        formPanel.add(new JLabel("ID:"));
        formPanel.add(idField);
        formPanel.add(new JLabel("prise:"));
        formPanel.add(priseField);
        formPanel.add(new JLabel(""));
        
    // Create a button for ADD COURSE
    JButton ADDButton = new JButton("ADD COURSE");
    ADDButton.addActionListener(e -> {
        // Get values from text fields
        String name = nameField.getText();
        String id = idField.getText();
         double prise =Double.parseDouble(priseField.getText());
    
        // Perform ADD COURSE
        if (name.isEmpty() || id.isEmpty() ) {
            // Display error message if any field is empty
            JOptionPane.showMessageDialog(titleLabel, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            Coach coach = new Coach();
            coach.addCourse(name, id, prise);
            
             JOptionPane.showMessageDialog(titleLabel, "Course Add successfully!");

            // Clear fields after registration
            nameField.setText("");
            idField.setText("");
            priseField.setText("");
        }
});formPanel.add(ADDButton );

        currentPanel.add(formPanel, BorderLayout.CENTER);

        JButton backBtn = new JButton("Back");
        backBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayMainMenu();
            }
        });
        currentPanel.add(backBtn, BorderLayout.SOUTH);

        revalidate();
        repaint();
    formPanel.add(ADDButton );

        currentPanel.add(formPanel, BorderLayout.CENTER);

        JButton backBt = new JButton("Back");
        backBt.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayCoachMenu();
            }
        });
        currentPanel.add(backBtn, BorderLayout.SOUTH);

        revalidate();
        repaint();

}

private void displayTraineeProfiles() {
    // Implement trainee profiles GUI
    // This method will display trainee profiles that the coach can view
}

  private void displayTraineeRegistration() {
    // Create a new JFrame for trainee registration
    JFrame traineeFrame = new JFrame("Trainee Registration");

    // Create labels and text fields for trainee registration
    JLabel nameLabel = new JLabel("Name:");
    JTextField nameField = new JTextField();
    JLabel idLabel = new JLabel("ID:");
    JTextField idField = new JTextField();
    JLabel emailLabel = new JLabel("Email:");
    JTextField emailField = new JTextField();
    JLabel phoneLabel = new JLabel("Phone:");
    JTextField phoneField = new JTextField();
    JLabel sexLabel = new JLabel("Sex:");
    JTextField sexField = new JTextField();
    JLabel weightLabel = new JLabel("Weight:");
    JTextField weightField = new JTextField();
    JLabel heightLabel = new JLabel("Height:");
    JTextField heightField = new JTextField();
    JLabel goalLabel = new JLabel("Goal:");
    JTextField goalField = new JTextField();

    // Create a button for trainee registration
    JButton registerButton = new JButton("Register");
    registerButton.addActionListener(e -> {
        // Get values from text fields
        String name = nameField.getText();
        String id = idField.getText();
        String email = emailField.getText();
        String phone = phoneField.getText();
        String sex = sexField.getText();
        double weight = Double.parseDouble(weightField.getText());
        double height = Double.parseDouble(heightField.getText());
        String goal = goalField.getText();

        // Perform trainee registration
        if (name.isEmpty() || id.isEmpty() || email.isEmpty() || phone.isEmpty() || sex.isEmpty() || goal.isEmpty()) {
            // Display error message if any field is empty
            JOptionPane.showMessageDialog(traineeFrame, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            // Create a new Trainee instance
           Trainee trainee = new Trainee();
            
            // Register the trainee
           // trainee.register(name, id, email);
            
            faced.registerTrainee();
            trainee.createProfile(phone, sex, weight, height, goal);
            // For demo purposes, display a success message
            JOptionPane.showMessageDialog(traineeFrame, "Trainee registered successfully!");
                 displayTraineeMenu();
            // Clear fields after registration
            nameField.setText("");
            idField.setText("");
            emailField.setText("");
            phoneField.setText("");
            sexField.setText("");
            weightField.setText("");
            heightField.setText("");
            goalField.setText("");
        }
    });

    // Create a JPanel to hold the components
    JPanel panel = new JPanel();
    panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
    panel.add(nameLabel);
    panel.add(nameField);
    panel.add(idLabel);
    panel.add(idField);
    panel.add(emailLabel);
    panel.add(emailField);
    panel.add(phoneLabel);
    panel.add(phoneField);
    panel.add(sexLabel);
    panel.add(sexField);
    panel.add(weightLabel);
    panel.add(weightField);
    panel.add(heightLabel);
    panel.add(heightField);
    panel.add(goalLabel);
    panel.add(goalField);
    panel.add(registerButton);

    // Add panel to the frame
    traineeFrame.getContentPane().add(panel);

    // Set frame properties
    traineeFrame.setSize(400, 400);
    traineeFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    traineeFrame.setVisible(true);
}
 private void displayTraineeMenu() {
    JFrame  mainFrame = new JFrame("Training Management System");
        mainFrame.setSize(400, 300);
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Add buttons to the main frame for testing purposes
        JPanel panel = new JPanel();
        mainFrame.getContentPane().add(panel);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JButton traineeViewCoursesButton = new JButton("View Courses");
        traineeViewCoursesButton.addActionListener(e -> 
               TraineeViewCourse());
        panel.add(traineeViewCoursesButton);

        
 JButton viewTraineeProfilesButton = new JButton("Select Course");
        viewTraineeProfilesButton.addActionListener(e -> {
            // Add the logic for selecting profiles here
        });
        panel.add(viewTraineeProfilesButton);
   

        JButton exitBtn = new JButton("Exit");
        exitBtn.addActionListener(e -> mainFrame.dispose());
        panel.add(exitBtn);

        mainFrame.setVisible(true);
    }
 private void TraineeViewCourse() {
         // Create a new JFrame for viewing courses
        JFrame viewCoursesFrame = new JFrame("View Courses");

        // Fetch the list of courses from the coach
        Coach coach=new Coach();
        ArrayList<Course> courses = coach.getCourses();
        
        // Create a JTextArea to display the courses
        JTextArea courseTextArea = new JTextArea();
        courseTextArea.setEditable(false);
        for (Course course : courses) {
            courseTextArea.append(course.toString() + "\n");
        }

        // Add the JTextArea to a JScrollPane for better viewing
        JScrollPane scrollPane = new JScrollPane(courseTextArea);

        // Create a button to close the view courses frame
        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> viewCoursesFrame.dispose());

        // Add the components to the frame
        viewCoursesFrame.getContentPane().setLayout(new BorderLayout());
        viewCoursesFrame.getContentPane().add(scrollPane, BorderLayout.CENTER);
        viewCoursesFrame.getContentPane().add(closeButton, BorderLayout.SOUTH);

        // Set frame properties
        viewCoursesFrame.setSize(400, 300);
        viewCoursesFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        viewCoursesFrame.setVisible(true);
    }

    
}
