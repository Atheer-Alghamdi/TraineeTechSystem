package traineeteachsystem;


class UserFactory {
    public static User createUser(String userType) {
        if (userType.equalsIgnoreCase("Coach")) {
            return new Coach();
        } else if (userType.equalsIgnoreCase("Trainee")) {
            return new Trainee();
        } else {
            throw new IllegalArgumentException("Unknown user type: " + userType);
        }
    }
}
