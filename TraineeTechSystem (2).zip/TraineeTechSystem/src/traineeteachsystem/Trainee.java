
package traineeteachsystem;



import java.util.ArrayList;


public class Trainee implements Observer ,User{
    private String name;
    private String ID;
    private String email;
    private String phone;
    private String sex;
    private double weight;
    private double height;
    private String goal;

    @Override
    public void update(String message) {
        System.out.println("----------------------NOTIFY--------------------\n"+"Trainees Notification --> " + message);
        
    }

    public void register(String name, String ID, String email) {
        this.name = name;
        this.ID = ID;
        this.email = email;
        System.out.println("Trainee registered successfully");
    }

    public void createProfile(String phone, String sex, double weight, double height, String goal) {
        this.phone = phone;
        this.sex = sex;
        this.weight = weight;
        this.height = height;
        this.goal = goal;
        System.out.println("Profile created for Trainee: " + name);
    }

    public void viewCourses(ArrayList<Course> courses) {
        System.out.println("Available Courses:");
        for (Course course : courses) {
            System.out.println(course);
        }
    }

    public void selectCourse(ArrayList<Course> courses, String courseId) {
        for (Course course : courses) {
            if (course.getCourseId().equals(courseId)) {
                System.out.println("Course selected: " + course.getName());
                return;
            }
        }
        System.out.println("Course not available.");
    }
      @Override
    public String toString() {
        return "Trainee{" +
                "ID='" + ID + '\'' +
                ", email='" + email + '\'' +
                ", phone='" + phone + '\'' +
                ", sex='" + sex + '\'' +
                ", weight=" + weight +
                ", height=" + height +
                ", goal='" + goal + '\'' +
                '}';
    }

    public String getName() {
        return name;
    }

    public String getID() {
        return ID;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getSex() {
        return sex;
    }

    public double getWeight() {
        return weight;
    }

    public double getHeight() {
        return height;
    }

    public String getGoal() {
        return goal;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public void setGoal(String goal) {
        this.goal = goal;
    }
    
}