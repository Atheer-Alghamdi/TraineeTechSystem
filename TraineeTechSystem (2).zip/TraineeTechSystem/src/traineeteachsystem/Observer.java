
package traineeteachsystem;


interface Observer {
    void update(String message); 
}
