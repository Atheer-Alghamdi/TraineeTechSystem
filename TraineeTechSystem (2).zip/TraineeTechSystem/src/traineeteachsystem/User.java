
package traineeteachsystem;


    interface User {
    void register(String name, String ID, String email);
}


