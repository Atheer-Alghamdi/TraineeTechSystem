
package traineeteachsystem;

import java.util.ArrayList;
import java.util.Scanner;

public class TrainingManagementFacade {
    private ArrayList<Trainee> trainees;
    private Coach coach;
    private Scanner scanner;

    public TrainingManagementFacade() {
        trainees = new ArrayList<>();
        coach = new Coach();
        scanner = new Scanner(System.in);
    }

    public void start() {
        //System.out.println("Welcome to the Training Management System!");
        //stratgy pattern Use welcome strategies as needed
        WelcomePage welcomePage = new WelcomePage();
        welcomePage.setWelcomeStrategy(new FormalWelcome());
        welcomePage.displayWelcome();
        while (true) {
            System.out.println("\nAre you registering as a 'Coach' or 'Trainee' or 'Exit'?");
            String userType = scanner.nextLine();
            if (userType.equalsIgnoreCase("Coach")) {
                welcomePage.setWelcomeStrategy(new CoachWelcome());
                 welcomePage.displayWelcome();
                registerCoach();
                manageCoach();
            } else if (userType.equalsIgnoreCase("Trainee")) {
                welcomePage.setWelcomeStrategy(new TraineeWelcome());
                welcomePage.displayWelcome();
                Trainee trainee = registerTrainee();
                coach.registerObserver(trainee); // Register trainee as an observer
                manageTrainee(trainee);
            } else if (userType.equalsIgnoreCase("Exit")) {
                System.out.println("Exiting the system. Thank you!");
                break;
            } else {
                System.out.println("Invalid input, please try again.");
            }
        }
        scanner.close();
    }

   public void registerCoach() {
        System.out.println("Registering as Coach");
        System.out.print("Enter Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter ID: ");
        String ID = scanner.nextLine();
        System.out.print("Enter Email: ");
        String email = scanner.nextLine();
        coach.register(name, ID, email);
    }

   public Trainee registerTrainee() {
        System.out.println("Registering as Trainee");
        System.out.print("Enter Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter ID: ");
        String ID = scanner.nextLine();
        System.out.print("Enter Email: ");
        String email = scanner.nextLine();

        Trainee trainee = new Trainee();
        trainee.register(name, ID, email);

        System.out.print("Enter Phone: ");
        String phone = scanner.nextLine();
        System.out.print("Enter Sex: ");
        String sex = scanner.nextLine();
        System.out.print("Enter Weight: ");
        double weight = scanner.nextDouble();
        System.out.print("Enter Height: ");
        double height = scanner.nextDouble();
        scanner.nextLine(); // Consume newline left-over
        System.out.print("Enter Goal: ");
        String goal = scanner.nextLine();
        
        trainee.createProfile(phone, sex, weight, height, goal);
        trainees.add(trainee);

        return trainee;
    }

    private void manageCoach() {
        while (true) {
            System.out.println("\n1: Add a course");
            System.out.println("2: View trainee profiles");
            System.out.println("3: Return to main menu");
            System.out.print("Enter choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline left-over
            if (choice == 1) {
                System.out.print("Enter Course Name: ");
                String name = scanner.nextLine();
                System.out.print("Enter Course ID: ");
                String courseId = scanner.nextLine();
                System.out.print("Enter Price: ");
                double price = scanner.nextDouble();
                scanner.nextLine(); // Consume newline left-over
                coach.addCourse(name, courseId, price);
            } else if (choice == 2) {
                System.out.print("\nEnter Coach ID to view trainee profile: ");
                String coachIdInput = scanner.nextLine();
                coach.viewTraineeProfiles(trainees, coachIdInput);
            } else if (choice == 3) {
                break;
            } else {
                System.out.println("Invalid choice, please try again.");
            }
        }
    }

    private void manageTrainee(Trainee trainee) {
        while (true) {
            System.out.println("\n1: View available courses");
            System.out.println("2: Select a course");
            System.out.println("3: Return to main menu");
            System.out.print("Enter choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline left-over
            if (choice == 1) {
                trainee.viewCourses(coach.getCourses());
            } else if (choice == 2) {
                System.out.print("Enter Course ID to select: ");
                String courseId = scanner.nextLine();
                trainee.selectCourse(coach.getCourses(), courseId);
            } else if (choice == 3) {
                break;
            } else {
                System.out.println("Invalid choice, please try again.");
            }
        }
    }
}
