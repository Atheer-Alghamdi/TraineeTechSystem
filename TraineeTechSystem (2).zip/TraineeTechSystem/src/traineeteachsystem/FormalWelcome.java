/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package traineeteachsystem;

/**
 *
 * @author uthir
 */
// Stratgy pattern
class FormalWelcome implements WelcomeStrategy {
    @Override
    public void displayWelcome() {
        System.out.println("Welcome! We are delighted to have you.");
    }
}
